package com.`as`.lab9

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import com.`as`.lab9.databinding.ActivtyMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivtyMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivtyMainBinding.inflate(layoutInflater)

        setContentView(binding.root)


        binding.loginButton.setOnClickListener {
            println(binding.emailEdittext.text)
        }
    }


}